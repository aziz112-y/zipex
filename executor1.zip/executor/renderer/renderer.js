// Get DOM elements
const connectBtn = document.getElementById('connect-btn');
const disconnectBtn = document.getElementById('disconnect-btn');
const machineKeyInput = document.getElementById('machine-key-input');
const statusIndicator = document.getElementById('status-indicator');
const statusText = document.getElementById('status-text');
const logContent = document.getElementById('log-content');
const logMessages = document.getElementById('log-messages');

// Connection state
let isConnected = false;

// Helper function to add a log entry
function addLogEntry(message) {
  const entry = document.createElement('div');
  entry.className = 'log-entry text-sm text-gray-300';
  entry.textContent = message;
  logMessages.appendChild(entry);

  // Auto-scroll to bottom
  logMessages.scrollTop = logMessages.scrollHeight;

  // If logs are hidden, show them
  if (logContent.classList.contains('hidden')) {
    toggleLogs();
  }
}

// Function to toggle logs visibility
function toggleLogs() {
  const toggleIcon = document.getElementById('toggle-icon');
  if (logContent.classList.contains('hidden')) {
    logContent.classList.remove('hidden');
    toggleIcon.style.transform = 'rotate(180deg)';
  } else {
    logContent.classList.add('hidden');
    toggleIcon.style.transform = 'rotate(0deg)';
  }
}

// Function to update connection status UI
function updateStatusUI(status) {
  statusIndicator.classList.remove('bg-red-500', 'bg-green-500');
  
  switch (status) {
    case 'connected':
      statusIndicator.classList.add('bg-green-500');
      statusText.textContent = 'Status: Connected';
      connectBtn.disabled = true;
      disconnectBtn.disabled = false;
      machineKeyInput.disabled = true;
      isConnected = true;
      break;
    case 'disconnected':
      statusIndicator.classList.add('bg-red-500');
      statusText.textContent = 'Status: Disconnected';
      connectBtn.disabled = false;
      disconnectBtn.disabled = true;
      machineKeyInput.disabled = false;
      isConnected = false;
      break;
    case 'error':
      statusIndicator.classList.add('bg-red-500');
      statusText.textContent = 'Status: Connection Error';
      connectBtn.disabled = false;
      disconnectBtn.disabled = true;
      machineKeyInput.disabled = false;
      isConnected = false;
      break;
    default:
      statusIndicator.classList.add('bg-red-500');
      statusText.textContent = 'Status: Disconnected';
      isConnected = false;
  }
}

// Initialize with disconnected status
updateStatusUI('disconnected');

// Check if window.api is defined
if (typeof window.api === 'undefined') {
  addLogEntry('Error: window.api is not defined!');
} else {
  // Connect button
  connectBtn.addEventListener('click', async () => {
    const machineKey = machineKeyInput.value.trim();

    if (!machineKey) {
      addLogEntry('Error: Machine API Key is required');
      return;
    }

    try {
      connectBtn.disabled = true;
      addLogEntry(`Connecting with key: ${machineKey}...`);

      if (typeof window.api.connect !== 'function') {
        addLogEntry('Error: connect method is not defined in window.api');
        return;
      }

      const result = await window.api.connect(machineKey);

      if (result.success) {
        addLogEntry('Connection request sent successfully');
        updateStatusUI('connected');
      } else {
        addLogEntry(`Connection failed: ${result.error}`);
        updateStatusUI('error');
      }
    } catch (error) {
      addLogEntry(`Error: ${error.message}`);
      updateStatusUI('error');
      connectBtn.disabled = false;
    }
  });

  // Disconnect button
  disconnectBtn.addEventListener('click', async () => {
    try {
      disconnectBtn.disabled = true;
      addLogEntry('Disconnecting...');

      if (typeof window.api.disconnect !== 'function') {
        addLogEntry('Error: disconnect method is not defined in window.api');
        return;
      }

      const result = await window.api.disconnect();

      if (result.success) {
        addLogEntry('Disconnected successfully');
        updateStatusUI('disconnected');
      } else {
        addLogEntry(`Disconnection failed: ${result.error}`);
      }
    } catch (error) {
      addLogEntry(`Error: ${error.message}`);
      updateStatusUI('error');
    }
  });

  // Listen for log messages from main process
  window.api.onLogMessage((message) => {
    addLogEntry(message);
  });

  // Listen for connection status updates
  window.api.onConnectionStatus((status) => {
    updateStatusUI(status);
  });

  // Restore previous status and logs
  if (typeof window.api.onRestoreLastStatus === 'function') {
    window.api.onRestoreLastStatus(({ logs, status }) => {
      updateStatusUI(status);
      logs.forEach(addLogEntry);
    });
  }
}
