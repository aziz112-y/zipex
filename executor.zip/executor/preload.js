const { contextBridge, ipcRenderer, shell } = require('electron');

contextBridge.exposeInMainWorld('api', {
    connect: (machineKey) => ipcRenderer.invoke('connect', machineKey),
    disconnect: () => ipcRenderer.invoke('disconnect'),

    // Handle log messages
    onLogMessage: (callback) => ipcRenderer.on('log-message', (_, message) => callback(message)),

    // Handle connection status updates
    onConnectionStatus: (callback) => ipcRenderer.on('connection-status', (_, status) => callback(status)),

    // Handle restored logs and status when connection is back
    onRestoreLastStatus: (callback) => ipcRenderer.on('restore-last-status', (_, data) => callback(data)),

    // Open download link
    openDownloadLink: (url) => ipcRenderer.send('open-download-link', url)
});

console.log("Preload script executing...");

try {
    contextBridge.exposeInMainWorld('electron', {
        onDownloadUrl: (callback) => {
            console.log("Registering onDownloadUrl handler");
            ipcRenderer.on('set-download-url', (event, url) => {
                console.log("Received URL in preload:", url);
                callback(url);
            });
        },
        openExternal: (url) => {
            console.log("openExternal called with:", url);
            return ipcRenderer.invoke('open-external-url', url);
        }
    });

    console.log("API successfully exposed!");
} catch (error) {
    console.error("Error exposing API:", error);
}

console.log("Preload script completed, exposed API:", Object.keys(contextBridge.exposeInMainWorld).length > 0 ? "OK" : "Failed");
